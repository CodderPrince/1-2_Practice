"""Text file Plagiarism Checker"""
"""
Name:   Prince
Id:     12105007
Plagiarism: (total simmilar words / total words)    *   100 %

Availability:   
directly text       to      directly text
"""


from flask import Flask, render_template, request
import subprocess
app = Flask(__name__)


@app.route('/')
def index():
    return render_template('index.html')


@app.route('/result', methods=['POST'])
def result():
    # Get content from the two text boxes
    document1 = request.form['document1']
    document2 = request.form['document2']

    # Write the content to temporary files
    with open('document1.txt', 'w') as f1, open('document2.txt', 'w') as f2:
        f1.write(document1)
        f2.write(document2)

    # Run the plagiarism checker C++ program
    result = subprocess.run(['./plagiarism.out'], capture_output=True)

    # Get the output of the C++ program
    output = result.stdout.decode('utf-8')

    return render_template('result.html', output=output)


if __name__ == '__main__':
    app.run(debug=True)
